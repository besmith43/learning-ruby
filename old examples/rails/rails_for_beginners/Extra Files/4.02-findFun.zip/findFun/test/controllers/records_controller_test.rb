require 'test_helper'

class RecordsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
