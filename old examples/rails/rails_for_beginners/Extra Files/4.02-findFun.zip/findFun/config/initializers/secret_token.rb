# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
FindFun::Application.config.secret_key_base = '3b46784db4be929015625ff0e2d450fccd386280d927326614e45c21fa0685b42c306aff21acb0059566778058fb9dfdbc8680c682768dbcb6aa88cbdc74d3f8'
