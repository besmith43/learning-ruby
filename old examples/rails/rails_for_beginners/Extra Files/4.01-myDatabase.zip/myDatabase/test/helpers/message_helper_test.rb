require 'test_helper'

class MessageHelperTest < ActionView::TestCase
end
