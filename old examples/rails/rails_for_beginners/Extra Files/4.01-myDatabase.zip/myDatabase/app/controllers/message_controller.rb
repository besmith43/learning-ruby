class MessageController < ApplicationController
end
