# Be sure to restart your server when you modify this file.

LoopsTest::Application.config.session_store :cookie_store, key: '_loopsTest_session'
