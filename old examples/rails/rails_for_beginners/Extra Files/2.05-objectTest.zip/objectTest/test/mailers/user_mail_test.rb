require 'test_helper'

class UserMailTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
