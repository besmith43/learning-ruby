class testPageController < ApplicationController
  def index
  end
end