class UserMail < ActionMailer::Base
  default from: "from@example.com"
end
