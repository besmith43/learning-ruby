# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
DeleteTest::Application.config.secret_key_base = 'c4faf3101f67673bc928e77b21168b9b0712962e2333fa60319936dfc3197ed76d55dcdd68b9cb040d18eb68b597532b65e266e2bca92a1e26b4e44fc08fd002'
