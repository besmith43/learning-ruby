class RecordsController < ApplicationController
end
