class AddIsbnToRecords < ActiveRecord::Migration
  def change
    add_column :records, :ISBN, :string
  end
end
