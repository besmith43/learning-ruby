class RecordsController < ApplicationController
  before_action :set_resutls, only: [:show]
	def index
		@records =Record.first(10)
  end

  def search
  end

  def show
  end
private 
 
	def set_resutls
      
		@results = Record.where(code: params[:q])
   end
end