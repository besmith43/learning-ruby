class ColorController < ApplicationController
 before_action :set_default
def picker
		if(params[:commit] == "Show")
				set_colors
				set_session
		 elsif (params[:commit] == "Delete Session")
				delete_session
				
	   else	
			set_default
		end
	end

	private
			def set_default
				if (!request.post?)
					if (session[:color1].blank?)
						@color1="style=background-color:#FFF;"
						@color2="style=background-color:#FFF;"
						@color3="style=background-color:#FFF;"
						@color4="style=background-color:#FFF;"
						@user_name="Guest"
					else
						@color1="style=background-color:"+session[:color1]
						@color2="style=background-color:"+session[:color2]
						@color3="style=background-color:"+session[:color3]
						@color4="style=background-color:"+session[:color4]
						@user_name=session[:user_name]
				end	
			end
		end
		def set_colors
				@user_name=params[:user_name]
				@color1="style=background-color:"+params[:first]
				@color2="style=background-color:"+params[:second]
				@color3="style=background-color:"+params[:third]
				@color4="style=background-color:"+params[:forth]
		
		end
		def set_session
			session[:user_name]=params[:user_name]
			session[:color1]=params[:first]
			session[:color2]=params[:second]
			session[:color3]=params[:third]
			session[:color4]=params[:forth]
		end
		def delete_session
			session.delete :color1
			session.delete :color2
			session.delete :color2
			session.delete :color3
			session.delete :user_name
		end
end