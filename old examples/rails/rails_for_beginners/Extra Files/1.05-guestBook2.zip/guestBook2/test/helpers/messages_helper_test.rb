require 'test_helper'

class MessagesHelperTest < ActionView::TestCase
end
