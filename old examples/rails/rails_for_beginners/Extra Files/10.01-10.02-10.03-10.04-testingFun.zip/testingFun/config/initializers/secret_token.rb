# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
ScaffoldTest::Application.config.secret_key_base = 'b251f1a6b6478bfdc6286723fd900794b10af8a8f140fb636a25a17d12fe4ef98fbb5e14fa8b784ac652c62ad1f4f9054da8ca57afed4049533b0caca3b498c4'
