require 'test_helper'

class GuestBookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
test "should not save guest_book without message" do
  guest_book = GuestBook.new
  assert !guest_book.save, "Saved the guest book without a message"
end

end
