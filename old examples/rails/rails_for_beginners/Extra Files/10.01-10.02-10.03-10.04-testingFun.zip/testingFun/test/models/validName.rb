require 'test_helper'

class GuestBookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
	
test "should not save guest_book with invalid user" do

	@guest_book = GuestBook.new
	@guest_book.user="Steven2"
		assert_match( /\b[a-zA-Z]{6,20}\b/, @guest_book.user, " is not 6 to 20 letters" ) 
  end

end
