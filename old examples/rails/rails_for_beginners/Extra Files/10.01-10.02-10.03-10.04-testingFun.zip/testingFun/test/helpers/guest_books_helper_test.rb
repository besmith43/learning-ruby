require 'test_helper'

class GuestBooksHelperTest < ActionView::TestCase
end
