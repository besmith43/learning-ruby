class GuestBook < ActiveRecord::Base
validates :message, presence: true
#validates_format_of :user, :with =>/\b[a-zA-Z]{6,20}\b/
end
