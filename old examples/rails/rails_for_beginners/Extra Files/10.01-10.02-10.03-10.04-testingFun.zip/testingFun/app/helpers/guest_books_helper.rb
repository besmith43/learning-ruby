module GuestBooksHelper
end
