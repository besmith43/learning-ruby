# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
ConditionTesting::Application.config.secret_key_base = '5d859fe8d337e54203bba1eb83a61e856bcbb4d47171f3c6a1517e4a8738c991a5260396d2d8922a5c87e3bccf8750b6f4ec8dc5089bdea929d6c0078746c7b9'
