module SelectionsHelper
	
end
