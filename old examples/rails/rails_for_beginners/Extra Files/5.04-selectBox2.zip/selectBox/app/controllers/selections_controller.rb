class SelectionsController < ApplicationController
  	def index
		
  end
end
