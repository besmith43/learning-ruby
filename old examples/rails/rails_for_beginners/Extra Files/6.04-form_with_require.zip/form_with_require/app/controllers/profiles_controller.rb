class ProfilesController < ApplicationController
before_action :set_profile, only: [:show, :edit, :update, :destroy]  
def index
@profiles = Profile.all
  end

  def show
  end

  def edit
  end
	
	def new
		@profile = Profile.new
	end
	def create 
	@gender = params[:gender] == "1"
	@profile=Profile.new(params.require(:profile).permit(:fname,:lname,:street,:city,:state, :zip,:phone,:age,:gender,:about, :profile_pic))
			@profile.gender=@gender
			
			if(@profile.save) 
				redirect_to :profiles
			else 
				render action: 'new'
			end
	end
	  def update
			respond_to do |format|
			  @gender = params[:gender] == "1"
    			params[:gender]=@gender
			if @profile.update(params.require(:profile).permit(:fname,:lname,:street,:city,:state, :zip,:phone,:age,:gender,:about,:profile_pic))
			 
				format.html { 
				flash[:notice] ='Profile was updated.'       
				redirect_to :profiles 
			  }       
			      else
			         render action: 'edit' 
			        
			      end
			   end 
	  end

	  def destroy
		respond_to do |format|
			format.html { 
					 if @profile.destroy
						flash[:notice] ='Profile was Deleted.'       
					     
				   else
				        flash[:notice] ='Profile Could Not Be Deleted.'       
					 end
				   redirect_to :profiles
			}
			 
		 end
	  end

		private
		def set_profile
			@profile =Profile.find(params[:id])
		end
	
end
