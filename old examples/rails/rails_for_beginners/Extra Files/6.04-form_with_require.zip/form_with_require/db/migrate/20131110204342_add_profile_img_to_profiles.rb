class AddProfileImgToProfiles < ActiveRecord::Migration
  def change
  end
end
