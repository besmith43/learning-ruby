class RecordsController < ApplicationController
  before_action :set_resutls, only: [:show]
	def index
		@records =Record.first(10)
  end

  def search
  end

  def show
  end
private 
 
	def set_resutls
     #This is not really safe!  
		@results = Record.where("artist like ?", params[:q])
   end
end