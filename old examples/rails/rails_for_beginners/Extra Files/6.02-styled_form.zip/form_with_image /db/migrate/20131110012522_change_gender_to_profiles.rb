class ChangeGenderToProfiles < ActiveRecord::Migration
  def change
  end
end
