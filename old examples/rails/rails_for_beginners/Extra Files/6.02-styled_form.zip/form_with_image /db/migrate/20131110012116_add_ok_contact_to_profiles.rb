class AddOkContactToProfiles < ActiveRecord::Migration
  def change
    add_column :profiles, :okContact, :boolean
  end
end
