require 'test_helper'

class SelectionsHelperTest < ActionView::TestCase
end
