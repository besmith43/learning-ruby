class Profile < ActiveRecord::Base
has_attached_file :profile_pic, :styles => { :medium => "300x300>", :thumb => "100x100>" }, :default_url => "/images/:style/missing.png"

validates_presence_of :fname, :lname, :phone,:zip,:email 

validates :email, format: {with:/\A^(|(([A-Za-z0-9]+_+)|([A-Za-z0-9]+\-+)|([A-Za-z0-9]+\.+)|([A-Za-z0-9]+\++))*[A-Za-z0-9]+@((\w+\-+)|(\w+\.))*\w{1,63}\.[a-zA-Z]{2,6})\z/i, message:"this is not a valid email address!"}

validates :phone, format:{with:/\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/, message:"Please use a valid phone number format!"}
end
