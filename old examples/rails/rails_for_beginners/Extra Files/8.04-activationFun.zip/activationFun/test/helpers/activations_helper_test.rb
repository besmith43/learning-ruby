require 'test_helper'

class ActivationsHelperTest < ActionView::TestCase
end
