class UsersController < ApplicationController
 before_action :set_user, only: [ :destroy] 
before_action :valid_user, only: [:activate]  
 
def new
	@user=User.new 
  end
def index
	@users=User.all
  end
	def create 
		@user=User.new(params.require(:user).permit(:name,:email,:password,:password_confirmation))
	   @t="AA"+Time.now.seconds_since_midnight.to_s
		
		@user.activation_code= Digest::MD5.hexdigest(@t) 
		if @user.save
			    	UserMailer.welcome_email(@user).deliver
					 redirect_to :action => :index
						  else
			    @title = "Sign up"
			    render 'new'
		end 
	end
 def destroy
    @user.destroy
    redirect_to :action => 'index' 
end

def activate
	
end

private
		def set_user
		@user=User.find(params[:id])		end
		
		def valid_user
	  @user = User.find_by_id_and_activation_code(params[:id], params[:activation_code])
	if(@user.updated_at+23.hours>=Time.now)
			@user.active=true
			@user.save 
		end
		end
		
end