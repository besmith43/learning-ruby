class ColorController < ApplicationController
 before_action :set_default
def picker
     if request.post?
			set_colors
			set_cookies
   end
end
def show
end

private
		def set_default
			 if (!request.post?)
			 	if (cookies[:color1].blank?)
					@color1="style=background-color:#FFF;"
					@color2="style=background-color:#FFF;"
					@color3="style=background-color:#FFF;"
					@color4="style=background-color:#FFF;"
					@user_name="Guest"
				else
				   @color1="style=background-color:"+cookies[:color1]
					@color2="style=background-color:"+cookies[:color2]
					@color3="style=background-color:"+cookies[:color3]
					@color4="style=background-color:"+cookies[:color4]
					@user_name=cookies[:user_name]
				end
			end					
		end
		def set_colors
				@user_name=params[:user_name]
				@color1="style=background-color:"+params[:first]
				@color2="style=background-color:"+params[:second]
				@color3="style=background-color:"+params[:third]
				@color4="style=background-color:"+params[:forth]
		
		end
		def set_cookies
		cookies[:user_name]=params[:user_name]
				cookies[:color1]=params[:first]
				cookies[:color2]=params[:second]
				cookies[:color3]=params[:third]
				cookies[:color4]=params[:forth]
		end
end