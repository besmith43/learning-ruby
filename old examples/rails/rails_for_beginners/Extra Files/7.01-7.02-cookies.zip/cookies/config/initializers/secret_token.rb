# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Cookies::Application.config.secret_key_base = '76629bd392243bec284ade78bd23a72a93d95daa34fe0c651e559528d3364c8b85bb6c5d3d104f9c937cdcadd44a62296199f9690f16371625e9d3b7ba9139f6'
