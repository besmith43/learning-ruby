# Be sure to restart your server when you modify this file.

StringFun::Application.config.session_store :cookie_store, key: '_stringFun_session'
