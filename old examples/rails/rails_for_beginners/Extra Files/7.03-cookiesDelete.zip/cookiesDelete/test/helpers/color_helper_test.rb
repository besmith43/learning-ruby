require 'test_helper'

class ColorHelperTest < ActionView::TestCase
end
