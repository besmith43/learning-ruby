class ColorController < ApplicationController
def picker
		if(params[:commit] == "Show")
				set_colors
				set_cookies
		 elsif (params[:commit] == "Delete Cookies")
				delete_cookies
				
	   else	
			set_default
		end
	end
			

private
	def set_default
						if (cookies[:color1].blank?)
								@color1="style=background-color:#FFF;"
								@color2="style=background-color:#FFF;"
								@color3="style=background-color:#FFF;"
								@color4="style=background-color:#FFF;"
								@user_name="Guest"
						else
								@color1="style=background-color:"+cookies[:color1]
								@color2="style=background-color:"+cookies[:color2]
								@color3="style=background-color:"+cookies[:color3]
								@color4="style=background-color:"+cookies[:color4]
								@user_name=cookies[:user_name]
						end
		end
		def set_colors
				@user_name=params[:user_name]
				@color1="style=background-color:"+params[:first]
				@color2="style=background-color:"+params[:second]
				@color3="style=background-color:"+params[:third]
				@color4="style=background-color:"+params[:forth]
		
		end
		def set_cookies
			cookies[:user_name]=params[:user_name]
			cookies[:color1]=params[:first]
			cookies[:color2]=params[:second]
			cookies[:color3]=params[:third]
			cookies[:color4]=params[:forth]
		end
		def delete_cookies
			cookies.delete :color1
			cookies.delete :color2
			cookies.delete :color3
			cookies.delete :color4
			cookies.delete :user_name
		end
	
		
end