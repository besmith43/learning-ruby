class Record < ActiveRecord::Base
end
