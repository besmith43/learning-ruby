# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
QueryFun::Application.config.secret_key_base = 'febabeca2bbe3d2c9f1979b255b1a47626d909e78ea95fd7c4a996e3e9b03f05af5b8c9375fff77482e13775a30a5ab495196f574468a63d439bccc0843ee763'
