class RecordsController < ApplicationController
  before_action :set_resutls, only: [:show,]
	before_action :set_result, only: [:favorite]
	def index
		@records =Record.first(10)
  end

  def search
  end

  def show
  end
	def favorite
	
  end
private 
 
	def set_resutls
     #This is not really safe!  
		@results = Record.where("artist like ?", params[:q])
   end
def set_result
     	@result = Record.find(params[:id])
     @desc= params[:bestever]
   end
end