module ColorHelper
end
