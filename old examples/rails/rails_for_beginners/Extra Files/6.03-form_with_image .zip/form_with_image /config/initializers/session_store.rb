# Be sure to restart your server when you modify this file.

StyledForm::Application.config.session_store :cookie_store, key: '_styled_form_session'
