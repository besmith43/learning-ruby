class CreateProfiles < ActiveRecord::Migration
  def change
    create_table :profiles do |t|
      t.string :fname
      t.string :lname
      t.string :street
      t.string :city
      t.string :state
      t.string :zip
      t.text :about
      t.string :age

      t.timestamps
    end
  end
end
