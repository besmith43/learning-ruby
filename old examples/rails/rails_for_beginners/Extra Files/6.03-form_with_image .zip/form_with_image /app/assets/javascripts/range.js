$(document).ready(function() {
	$("input[type=range]").change(function(){
		$("#profile_age").val($(this).val());
		
	})
	
	});
