class UsersController < ApplicationController
 before_action :set_user, only: [:new, :edit, :update, :destroy]  
def new
	@user=User.new 
  end

	def create 
	@user=User.new(params.require(:user).permit(:name,:email,:password,:password_confirmation))
	  if @user.save
	    redirect_to :action => :index
	  else
	    @title = "Sign up"
	    render 'new'
	  end
	end
 
private
		def set_user
		@user=User.new
		end

end
