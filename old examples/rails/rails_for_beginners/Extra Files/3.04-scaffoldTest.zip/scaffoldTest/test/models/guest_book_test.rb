require 'test_helper'

class GuestBookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
