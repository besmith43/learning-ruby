class GuestBook < ActiveRecord::Base
end
