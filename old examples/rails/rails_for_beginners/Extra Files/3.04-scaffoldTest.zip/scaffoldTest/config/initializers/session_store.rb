# Be sure to restart your server when you modify this file.

ScaffoldTest::Application.config.session_store :cookie_store, key: '_scaffoldTest_session'
