# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
SecureUser::Application.config.secret_key_base = '0c7762e79cb453dd29f14d107aa89db28c84473d4a9aa859522ba0a67be390d0e3325dc425c690725dd3ca7e711c7e4cb46004ac864cd65776bed90fce18b5f4'
