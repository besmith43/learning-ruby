# Load the Rails application.
require File.expand_path('../application', __FILE__)

# Initialize the Rails application.
SecureUser::Application.initialize!


ActionMailer::Base.server_settings = {
   :address => "smtp.binaryblacksmith.com",
   :port => 25,
   :domain => "binaryblacksmith.com",
   :authentication => :login,
   :user_name => "daniel",
   :password => "platter222",
}