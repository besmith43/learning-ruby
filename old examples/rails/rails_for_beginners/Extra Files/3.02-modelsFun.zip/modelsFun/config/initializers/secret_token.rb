# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
ModelsFun::Application.config.secret_key_base = 'fbcecf116f0f0d0f67023c8c1898cfb5aa468ee7a074aa16fe1d8243b1d8d3e1a6ce12a37436ce92551b9c6436f3574c35803464720d0fffd54dcca622d39a13'
