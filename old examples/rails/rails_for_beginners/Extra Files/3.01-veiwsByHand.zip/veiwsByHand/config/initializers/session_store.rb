# Be sure to restart your server when you modify this file.

VeiwsByHand::Application.config.session_store :cookie_store, key: '_veiwsByHand_session'
